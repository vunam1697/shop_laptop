<?php

return [

    'views' => [

       	/* 'builder' => 'generator-builder::builder',

        'field-template' => 'generator-builder::field-template',

        'relation-field-template' => 'generator-builder::relation-field-template'*/

        'builder' => 'infyom.generator-builder.builder',

        'field-template' => 'infyom.generator-builder.field-template',

        'relation-field-template' => 'infyom.generator-builder.relation-field-template'

        
    ]
];