<?php

namespace App\Http\Controllers;

use App;
use DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use App\Models\Pages;
use App\Models\Options;
use App\Models\Service;
use DateTime;
use SEO;
use SEOMeta;
use OpenGraph;
use App\Models\Menu;
use Illuminate\Support\Facades\Mail;
use App\Models\Image;
use JsValidator;
use App\Models\Posts;
use App\Models\About;
use App\Models\Customer;
use App\Models\Projects;
use App\Models\Services;
use App\Models\Products;
use App\Models\Contact;
use App\Models\Categories;
use App\Models\ProductCategory;
use App\Http\Requests\ContactRequest;
use App\Models\PostCategory;


class IndexController extends Controller
{

	public $config_info;

    public function __construct()
    {
        $site_info = Options::where('type', 'general')->first();

        if ($site_info) {
            $site_info = json_decode($site_info->content);
            $this->config_info = $site_info;
            OpenGraph::setUrl(\URL::current());
            OpenGraph::addProperty('locale', 'vi');
            OpenGraph::addProperty('type', 'article');
            OpenGraph::addProperty('author', 'GCO-GROUP');

            SEOMeta::addKeyword($site_info->site_keyword);

            $menuHeader = Menu::where('id_group', 1)->orderBy('position')->get();
            $menuFooter = Menu::where('id_group', 2)->orderBy('position')->get();
            $menuCategory = Categories::where('type', 'product_category')->get();
            view()->share(compact('site_info', 'menuHeader', 'menuFooter', 'menuCategory'));
        }
    }

    public function createSeo($dataSeo = null)
    {
        $site_info = $this->config_info;
        if (!empty($dataSeo->meta_title)) {
            SEO::setTitle($dataSeo->meta_title);
        } else {
            SEO::setTitle($site_info->site_title);
        }
        if (!empty($dataSeo->meta_description)) {
            SEOMeta::setDescription($dataSeo->meta_description);
            OpenGraph::setDescription($dataSeo->meta_description);
        } else {
            SEOMeta::setDescription($site_info->site_description);
            OpenGraph::setDescription($site_info->site_description);
        }
        if (!empty($dataSeo->image)) {
            OpenGraph::addImage($dataSeo->image, ['height' => 400, 'width' => 400]);
        } else {
            OpenGraph::addImage($site_info->logo_share, ['height' => 400, 'width' => 400]);
        }
        if (!empty($dataSeo->meta_keyword)) {
            SEOMeta::addKeyword($dataSeo->meta_keyword);
        }
    }

    public function createSeoPost($data)
    {
        if(!empty($data->meta_title)){
            SEO::setTitle($data->meta_title);
        }else {
            SEO::setTitle($data->name);
        }
        if(!empty($data->meta_description)){
            SEOMeta::setDescription($data->meta_description);
            OpenGraph::setDescription($data->meta_description);
        }else {
            SEOMeta::setDescription($this->config_info->site_description);
            OpenGraph::setDescription($this->config_info->site_description);
        }
        if (!empty($data->image)) {
            OpenGraph::addImage($data->image, ['height' => 400, 'width' => 400]);
        } else {
            OpenGraph::addImage($this->config_info->logo_share, ['height' => 400, 'width' => 400]);
        }
        if (!empty($data->meta_keyword)) {
            SEOMeta::addKeyword($data->meta_keyword);
        }
    }

    public function getChangeLanguage($lang)
    {
        session(['lang' => $lang]);
        return redirect()->back();
    }

    public function getHome()
    { 
    	$this->createSeo();
        $contentHome = Pages::where('type', 'home')->whereLang(app()->getLocale())->first();
        $partner = Image::where('type', 'partner')->where('status', 1)->orderBy('created_at', 'DESC')->get();
        $slider = Image::where('type', 'slider')->where('status', 1)->orderBy('created_at', 'DESC')->get();
        $postHots = Posts::where('status', 1)->where('type', 'blog')->where('hot', 1)->orderBy('created_at', 'DESC')->take(4)->get();
        $services = Services::where('status', 1)->where('hot', 1)->orderBy('created_at', 'DESC')->get();
        $projects = Projects::where('status', 1)->where('hot', 1)->orderBy('created_at', 'DESC')->take(4)->get();
        $productsHot = Products::where('status', 1)->where('hot', 1)->orderBy('created_at', 'DESC')->get();
        return view('frontend.pages.home', compact('partner', 'slider', 'postHots', 'contentHome', 'productsHot','services','projects'));
    }

    public function getSearch(Request $request)
    {
        try {
            $dataSeo = Pages::where('type', 'product')->whereLang(app()->getLocale())->first();
            $this->createSeo($dataSeo);
            $products = Products::select('*');
            if ($request->get('name')) {
               $products->where('name', 'like', '%' . $request->get('name') . '%')->where('status', 1);
            }
            if ($request->get('trademark')) {
               $products->where('brand_id',$request->get('trademark'))->where('status', 1);
            }
            if ($request->get('producer')) {
                $products->where('producter_id',$request->get('producer'))->where('status', 1);
            }
            if ($request->get('origin')) {
                $products->where('origin_id',$request->get('origin'))->where('status', 1);
            }
            if ($request->get('model')) {
                $products->where('model_id',$request->get('model'))->where('status', 1);
            }
            if ($request->get('energy_source')) {
                $products->where('energy_sources_id',$request->get('energy_source'))->where('status', 1);
            }
            $products = $products->orderBy('created_at', 'DESC')->paginate(12);
            return view('frontend.pages.search', compact('products', 'dataSeo'));
        } catch (Exception $e) {
            about(500);
        }
    }

    public function getSort(Request $request)
    {
        $slug = $request->sort;
        $dataSeo = Pages::where('type', 'product')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        if ($slug == 'cu-nhat'){
            $products = Products::where('status', 1)->orderBy('created_at')->paginate(12);
            return view('frontend.pages.archives-products', compact('products', 'dataSeo', 'slug'));
        }
        elseif ($slug == 'tu-thap-toi-cao'){
            $products = Products::where('status', 1)->orderBy('price')->paginate(12);
            return view('frontend.pages.archives-products', compact('products', 'dataSeo', 'slug'));
        }
        else {
            $products = Products::where('status', 1)->orderBy('price','DESC')->paginate(12);
            return view('frontend.pages.archives-products', compact('products', 'dataSeo', 'slug'));
        }
    }

    public function getListAbout()
    {
        $dataSeo = Pages::where('type', 'about')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        return view('frontend.pages.about', compact('dataSeo'));
    }

    public function getListServices()
    {
        $dataSeo = Pages::where('type', 'service')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $services = Services::where('status', 1)->orderBy('id', 'DESC')->paginate(4);
        return view('frontend.pages.archives-service', compact('services','dataSeo'));
    }

    public function getSingleServices($slug)
    {
        $dataSeo = Pages::where('type', 'service')->whereLang(app()->getLocale())->first();
        $data = Services::where('status', 1)->where('slug', $slug)->firstOrFail();
        $this->createSeoPost($data);
        return view('frontend.pages.detail-service', compact('dataSeo', 'data'));
    }

    public function getListProjects()
    {
        $dataSeo = Pages::where('type', 'project')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $projects = Projects::where('status', 1)->orderBy('id', 'DESC')->paginate(12);
        return view('frontend.pages.archives-projects', compact('projects','dataSeo'));
    }

    public function getSingleProject($slug)
    {
        $dataSeo = Pages::where('type', 'project')->whereLang(app()->getLocale())->first();
        $data = Projects::where('status', 1)->where('slug', $slug)->firstOrFail();
        $this->createSeoPost($data);
        $project_same = Projects::where('id', '!=', $data->id )->where('status', 1)
                ->inRandomOrder()
                ->orderBy('created_at', 'DESC')
                ->take(10)->get();
        return view('frontend.pages.detail-project', compact('dataSeo', 'data', 'project_same'));
    }

    public function getListPost()
    {
        $dataSeo = Pages::where('type', 'news')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $listCategory = Categories::where('type', 'post_category')->get();
        $data = Posts::select('posts.*', 'post_category.id_category')->join('post_category', 'post_category.id_post', 'posts.id')
                ->where('posts.status', 1)->where('posts.type', 'blog')->orderBy('posts.created_at', 'DESC')->paginate(12);
        $dataHot = Posts::where('status', 1)->where('type', 'blog')->where('hot', 1)->orderBy('created_at')->take(10)->get();
        return view('frontend.pages.archives-news', compact('dataSeo', 'data', 'listCategory', 'dataHot'));
    }

    public function getSingleNews($slug)
    {
        $data = Posts::where('type', 'blog')->where('status', 1)->where('slug', $slug)->firstOrFail();
        $this->createSeoPost($data);
        $posts_same = Posts::where('id', '!=', $data->id)
                    ->where('status', 1)->inRandomOrder()->take(5)->get();
        $post_hot = Posts::where('status', 1)->where('type', 'blog')->where('hot', 1)->orderBy('created_at', 'DESC')->take(4)->get();
        return view('frontend.pages.detail-news', compact('data', 'posts_same', 'post_hot'));
    }

    public function getCategoryNews($slug)
    {
        $dataSeo = Pages::where('type', 'news')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $listCategory = Categories::where('type', 'post_category')->get();
        $category = Categories::where('slug', $slug)->where('type', 'post_category')->firstOrFail();
        $list_id_children = get_list_ids($category);
        $list_id_children[] = $category->id;
        $list_id_post = PostCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_post')->toArray();
        $data = Posts::whereIn('id', $list_id_post)->where('status', 1)->orderBy('created_at', 'DESC')->paginate(12);
        $dataHot = Posts::where('status', 1)->where('type', 'blog')->where('hot', 1)->orderBy('created_at')->take(10)->get();
        return view('frontend.pages.posts-cate', compact('data', 'category', 'listCategory', 'dataHot', 'dataSeo'));
    }

    public function getListProducts()
    {
        $dataSeo = Pages::where('type', 'product')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $products = Products::where('status', 1)->orderBy('created_at', 'DESC')->paginate(12);
        return view('frontend.pages.archives-products', compact('products', 'dataSeo'));
    }

    public function getSingleProduct($slug)
    {
        $data = Products::where('status', 1)->where('slug', $slug)->firstOrFail();
        $this->createSeoPost($data);
        $list_category = $data->category->pluck('id')->toArray();
        $list_post_related = ProductCategory::whereIn('id_category', $list_category)->get()->pluck('id_product')->toArray();
        $product_same_category = Products::where('id', '!=', $data->id)->where('status', 1)
                                ->whereIn('id', $list_post_related)->orderBy('created_at', 'DESC')->take(6)->get();
        $products = Products::where('status', 1)->orderBy('created_at', 'DESC')->get();
        return view('frontend.pages.detail-products', compact('data', 'product_same_category','products'));
    }

  

    public function getCatetoryProducts($slug)
    {
        // $category = Categories::where('slug', $slug)->firstOrFail();
        // $list_id_children = get_list_ids($category);
        // $list_id_children[] = $category->id;
        // $list_id_product = ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
        // $products = Products::whereIn('id', $list_id_product)->orderBy('created_at', 'DESC')->paginate(12);
        // $categorychildren = Categories::where('parent_id', $category->id)->get();
        // $this->createSeoPost($category);
        // return view('frontend.pages.products-cate', compact('products', 'category','categorychildren'));
        $dataSeo = Pages::where('type', 'product')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        $category = Categories::where('slug', $slug)->firstOrFail();
        $childCates = $category->get_child_cate();

        return view('frontend.pages.products-cate', compact('childCates', 'category', 'dataSeo'));
    }


    public function getContact()
    {
        $dataSeo = Pages::where('type', 'contact')->whereLang(app()->getLocale())->first();
        $this->createSeo($dataSeo);
        return view('frontend.pages.contact', compact('dataSeo'));
    }

    public function postContact(ContactRequest $request)
    {
        $data = [
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
        ];
        $customer = Customer::create($data);

        $contact = new Contact;
        $contact->title = 'Liên hệ từ khách hàng';
        $contact->customer_id = $customer->id;
        $contact->type = 'contact';
        $contact->content = $request->content;
        $contact->status = 0;
        $contact->save();

        $content_email = [
            'title' => 'Liên hệ từ khách hàng',
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'content' => $request->content,
            'url' => route('contact.edit', $contact->id),
        ];

        $email_admin = getOptions('general', 'email_admin');

        Mail::send('frontend.mail.mail-teamplate', $content_email, function ($msg) use($email_admin) {
            $msg->from('no.reply.bot.gco@gmail.com', 'Website - MA-SBTC');
            $msg->to($email_admin, 'Website - MA-SBTC')->subject('Liên hệ từ khách hàng');
        });
        return redirect()->back()->with([
            'flash_message' => ucfirst(trans('messages.thong_bao_thanh_cong')),
        ]);
    }


    public function getLoadMoreAjax(Request $request)
    {
        if($request->type == 'news'){
            $type = 'news';
            if (!empty($request->id_cat)) {
                $category = Categories::find($request->id_cat);
                $data = $category->Posts()->where('status', 1)->orderBy('created_at', 'DESC')->offset($request->limit)->take(12)->get();
            }
        }else {
            $type = 'products';
            if (!empty($request->id_cat)) {
                $category = Categories::find($request->id_cat);
                $data = $category->Products()->where('status', 1)->orderBy('created_at', 'DESC')->offset($request->limit)->get();
            }else {
                $data = Products::where('status', 1)->orderBy('created_at', 'DESC')->offset($request->limit)->take(12)->get();
            }
        }
        if(count($data)){
            if(!empty($category)){
                return view('frontend.components.loop', compact('type','data'));
            }
            return view('frontend.components.loop', compact('type', 'data'));
        }
        return response()->json(['status' => 0]);
    }

}
