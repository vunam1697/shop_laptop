<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContactRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'      => 'required|min:5|max:50',
            'phone'     => 'required|min:10|max:10',
            'email'     => 'required|email:rfc,dns,filter',
            'content'   => 'max:500',
        ];
    }
    public function messages()
    {
        return [
            'name.required'     => trans('messages.ban_chua_nhap_ho_ten_khach_hang'),
            'name.min'          => trans('messages.ho_ten_khong_the_nho_hon_5_ki_tu'),
            'name.max'          => trans('messages.ho_ten_khong_the_lon_hon_50_ki_tu'),
            'email.required'    => trans('messages.ban_chua_nhap_email'),
            'email.email'       => trans('messages.email_phai_la_mot_dia_chi_email_hop_le'),
            'email.rfc'         => trans('messages.email_phai_la_mot_dia_chi_email_hop_le'),
            'email.dns'         => trans('messages.email_phai_la_mot_dia_chi_email_hop_le'),
            'email.filter'      => trans('messages.email_phai_la_mot_dia_chi_email_hop_le'),
            'phone.required'    => trans('messages.ban_chua_nhap_so_dien_thoai'),
            'phone.min'         => trans('messages.so_dien_thoai_sai'),
            'phone.max'         => trans('messages.so_dien_thoai_sai'),
            'content.max'       => trans('messages.noi_dung_khong_duoc_lon_hon_500_ky_tu'),
        ];
    }
}
