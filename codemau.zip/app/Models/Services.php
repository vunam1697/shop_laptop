<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
   	protected $table = 'service';
   	protected $fillable = [ 
		'name', 'name_en', 'slug', 'desc', 'desc_en', 'image' , 'content', 'content_en',
		'hot' , 'status', 'meta_title', 'meta_description', 'meta_keyword', 'created_at' , 'updated_at'
	];
}