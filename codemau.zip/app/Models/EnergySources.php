<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EnergySources extends Model
{
   	protected $table = 'energy_sources';
   	protected $fillable = [ 
        'name', 'name_en','updated_at','created_at'
	];
}