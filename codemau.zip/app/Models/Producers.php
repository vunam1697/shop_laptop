<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Producers extends Model
{
   	protected $table = 'producer';
   	protected $fillable = [ 
        'name', 'name_en', 'updated_at','created_at'
	];
}