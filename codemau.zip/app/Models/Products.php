<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Brands;
use App\Models\Producers;
use App\Models\Origins;
use App\Models\Models;
use App\Models\EnergySources;
class Products extends Model
{
   	protected $table = 'products';
   	protected $fillable = [ 
        'code', 'slug', 'name', 'name_en' , 'price' , 'size' , 'size_en', 'guarantee' , 'guarantee_en', 'desc' , 'desc_en' , 
        'specifications' , 'specifications_en', 'image' , 'status', 'hot', 'content', 'content_en', 'more_image',
        'brand_id', 'producter_id', 'origin_id', 'model_id', 'energy_sources_id', 'meta_title', 'meta_description',
         'meta_keyword', 'created_at' , 'updated_at'
	];
   	public function category()
    {
        return $this->belongsToMany('App\Models\Categories', 'product_category', 'id_product', 'id_category');
    }
    public function trademark() {
        return $this->belongsTo(Brands::class);
    }
    public function producer() {
        return $this->belongsTo(Producers::class);
    }
    public function origin() {
        return $this->belongsTo(Origins::class);
    }
    public function model() {
        return $this->belongsTo(Models::class);
    }
    public function energy_source() {
        return $this->belongsTo(EnergySources::class);
    }
}