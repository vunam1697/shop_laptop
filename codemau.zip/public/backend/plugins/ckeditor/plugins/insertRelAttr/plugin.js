CKEDITOR.plugins.add( 'insertRelAttr', {
    icons: 'insertRelAttr',
    init: function( editor ) {
        // Plugin logic goes here...
    }
});