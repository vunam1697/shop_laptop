@extends('backend.layouts.app')
@section('controller', $module['name'] )
@section('controller_route', route($module['module'].'.index'))
@section('action', renderAction(@$module['action']))
@section('content')
	<div class="content">
		<div class="clearfix"></div>
       	@include('flash::message')
       	<form action="{!! updateOrStoreRouteRender( @$module['action'], $module['module'], @$data) !!}" method="POST">
			@csrf
			@if(isUpdate(@$module['action']))
		        {{ method_field('put') }}
		    @endif
			<div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#activity" data-toggle="tab" aria-expanded="true">Thông tin thương hiệu</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="activity">
						<div class="form-group">
							<label>Tên thương hiệu</label>
							<input type="text" class="form-control" name="name" id="name" value="{!! old('name', @$data->name) !!}" required="">
						</div>
						<div class="form-group">
							<label>Tên thương hiệu tiếng anh</label>
							<input type="text" class="form-control" name="name_en" id="name_en" value="{!! old('name', @$data->name_en) !!}" required="">
						</div>
					</div>
					<button type="submit" class="btn btn-primary">Lưu lại</button>
				</div>
			</div>
		</form>
	</div>
@stop