@extends('backend.layouts.app')
@section('controller','Trang báo giá')
@section('content')
    <div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                @include('flash::message')
                <form action="{{ route('backend.quotes.post') }}" method="POST">
                    {{ csrf_field() }}
                    <input type="hidden" name="id" value="{{ @$data->id }}"/>
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="#quote" data-toggle="tab" aria-expanded="true">Báo giá</a>
                            </li>
                            <li class="">
                                <a href="#procedure" data-toggle="tab" aria-expanded="true">Quá trình lắp đặt</a>
                            </li>
                        </ul>
                    </div>
                    
                    <?php if(!empty($data->content)){
                        $content = json_decode($data->content);
                    }?>
                    <div class="tab-content">
                        
                        <div class="tab-pane active" id="quote">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="repeater" id="repeater">
                                        <table class="table table-bordered table-hover quote">
                                            <thead>
                                                <tr>
                                                    <th style="width: 30px;">STT</th>
                                                    <th>Sản phẩm</th>
                                                    <th style="width: 20%;">ĐVT</th>
                                                    <th style="width: 20%;">Đơn giá</th>
                                                    <th style="width: 20px"></th>
                                                </tr>
                                            </thead>
                                            <tbody id="sortable">
                                                @if (!empty($content->quote->content))
                                                    @foreach ($content->quote->content as $key => $value)
                                                        <?php $index = $loop->index + 1 ; ?>
                                                        @include('backend.repeater.row-quote')
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                        <div class="text-right">
                                            <button class="btn btn-primary" 
                                                onclick="repeater(event,this,'{{ route('get.layout') }}','.index', 'quote', '.quote')">Thêm
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
										<label for="">Ghi chú</label>
										<textarea class="content" name="note">{!! old('note', @$data->note) !!}</textarea>
									</div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="procedure">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="repeater" id="repeater">
                                        <table class="table table-bordered table-hover procedure">
                                            <thead>
                                                <tr>
                                                    <th style="width: 30px;">STT</th>
                                                    <th width="200px">Icon</th>
                                                    <th>Mô tả</th>
                                                    <th style="width: 20px"></th>
                                                </tr>
                                            </thead>
                                            <tbody id="sortable">
                                                @if (!empty($content->procedure->content))
                                                    @foreach ($content->procedure->content as $key => $value)
                                                        <?php $index = $loop->index + 1 ; ?>
                                                        @include('backend.repeater.row-procedure')
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                        <div class="text-right">
                                            <button class="btn btn-primary" 
                                                onclick="repeater(event,this,'{{ route('get.layout') }}','.index', 'procedure', '.procedure')">Thêm
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <button type="submit" class="btn btn-primary">Lưu lại</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop