@extends('errors::minimal')

@section('title', __('404 - Không tìm thấy'))
    <section id="error">
        <div class="container">
            <div class="content text-center">
                <div class="avar"><img src="{{ url('/') }}/images/404.png" class="img-fluid" alt=""></div>
                <h1>Không tìm thấy trang</h1>
                <p>Trang đã bị xóa hoặc địa chỉ URL không đúng</p>
                <div class="gohome"><a title="" href="{{ url('/') }}">Quay về trang chủ</a></div>
            </div>
        </div>
    </section>