<?php 
use App\Models\Brands;
use App\Models\Producers;
use App\Models\Origins;
use App\Models\Models;
use App\Models\EnergySources;

$brands = Brands::get();
$producers = Producers::get();
$origins = Origins::get();
$models = Models::get();
$energy_sources = EnergySources::get();
?>
<div class="sidebar-left sticky-top">
    @if (count($menuCategory))
        <div class="sidebar-cate">
            <h2><span> {{ trans('messages.danh_muc_sp') }} </span></h2>
            <div class="cate-list">
                @foreach ($menuCategory as $item)
                    <?php
                        $countProduct = \App\Models\ProductCategory::where('id_category', $item->id)->count();
                        // $id_category = $item->id;
                        foreach ($item->get_child_cate() as $value) {
                            $count = \App\Models\ProductCategory::where('id_category', $value->id)->count();
                            $chile = \App\Models\Categories::where('id', $value->parent_id)->get();
							if ($chile) {
                                $countProduct = $countProduct + $count;
							}
							$countProduct = $countProduct;
                        }
                        // dd($countProduct);
                    ?>
                    @if ($item->parent_id == null)
                        <div class="cate-item">
                            @if (App::getLocale() == 'vi')
                                <div class="cate-cap">{{$item->name}} @if($countProduct > 0) ({{$countProduct}})  @endif</div>
                            @else
                                <div class="cate-cap">{{$item->name_en}} @if($countProduct > 0) ({{$countProduct}})  @endif</div>
                            @endif

                            <div class="cate-dropdown">
                                <ul>
                                @foreach ($menuCategory as $itemData)
                                    @if ($itemData->parent_id != null && $itemData->parent_id == $item->id)  
                                        @if (App::getLocale() == 'vi')
                                            <li><a href="{{ url('/danh-muc/'. $itemData->slug) }}" title="">- {{ $itemData->name }}</a> </li>
                                        @else
                                            <li><a href="{{ url('/danh-muc/'. $itemData->slug) }}" title="">- {{ $itemData->name_en }}</a> </li>
                                        @endif
                                    @endif
                                @endforeach   
                                </ul>
                            </div>
                        </div>

                    @endif
                @endforeach   
            </div>
        </div>
    @endif

    <form method="get" action="{{route('home.search')}}">
        <div class="sidebar-dropdown">
            {{-- <div class="current-select">{{ trans('messages.chon_thuong_hieu') }}</div>
            <div class="dropdown-select">
                <ul>
                    @foreach(@$brands as $brand)
                        <li>
                            <a href="" title="">
                                <input type="hidden" name="trademark" value="{{$brand->id}}" {{ request()->get('trademark') == $brand->id ? 'selected' : null }}>
                                {{App::getLocale() == 'vi' ? $brand->name : $brand->name_en}}
                            </a>
                        </li>
                    @endforeach 
                </ul>
            </div> --}}
            <select  name="trademark" class="form-control select2 select-group">
                <option value="">{{ trans('messages.chon_thuong_hieu') }}</option>
                @foreach(@$brands as $brand)
                    <option {{ request()->get('trademark') == $brand->id ? 'selected' : null }} value="{{$brand->id}}">{{App::getLocale() == 'vi' ? $brand->name : $brand->name_en}}</option>
                @endforeach 
            </select>
        </div>
        <div class="sidebar-dropdown">
            <select  name="producer" class="form-control select2 select-group">
                <option value="">{{ trans('messages.chon_nha_sx') }}</option>
                @foreach(@$producers as $producer)
                    <option {{ request()->get('producer') == $producer->id ? 'selected' : null }} value="{{$producer->id}}">{{App::getLocale() == 'vi' ? $producer->name : $producer->name_en}}</option>
                @endforeach 
            </select>
        </div>
        <div class="sidebar-dropdown">
                <select  name="origin" class="form-control select2 select-group">
                    <option value="">{{ trans('messages.chon_xuat_xu') }}</option>
                    @foreach(@$origins as $origin)
                        <option {{ request()->get('origin') == $origin->id ? 'selected' : null }} value="{{$origin->id}}">{{App::getLocale() == 'vi' ? $origin->name : $origin->name_en}}</option>
                    @endforeach 
                </select>
        </div>
        <div class="sidebar-dropdown">
                <select  name="model" class="form-control select2 select-group">
                    <option value="">{{ trans('messages.chon_model') }}</option>
                    @foreach(@$models as $model)
                        <option {{ request()->get('model') == $model->id ? 'selected' : null }} value="{{$model->id}}">{{App::getLocale() == 'vi' ? $model->name : $model->name_en}}</option>
                    @endforeach 
                </select>
        </div>
        <div class="sidebar-dropdown">
                <select  name="energy_source" class="form-control select2 select-group">
                    <option value="">{{ trans('messages.chon_nguon_nang_luong') }}</option>
                    @foreach(@$energy_sources as $energySource)
                        <option {{ request()->get('energy_source') == $energySource->id ? 'selected' : null }} value="{{$energySource->id}}">{{App::getLocale() == 'vi' ? $energySource->name : $energySource->name_en}}</option>
                    @endforeach 
                </select>   
        </div>
        <div class="text-right">
            <button class="view-mores frm-view-mores inflex-center-center">{{ trans('messages.tim_kiem') }}</button>
        </div>
    </form>
</div>


