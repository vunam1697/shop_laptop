<footer>
    <section class="footer-info">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h4>{{ trans('messages.thong_tin_lỉn_he') }}</h4>
                    <h5 class="com-name">{{ @$site_info->name_company }}</h5>
                    <ul class="com-info">
                        <li>
                            <i class="fa fa-map-marker"></i>
                            <div>
                            @if (@$site_info->address->list)
                                @foreach (@$site_info->address->list as $item)
                                    <p class="mgb-10">{{ App::getLocale() == 'vi' ? $item->title : $item->title_en }}</p>
                                @endforeach   
                                @endif
                            </div>
                        </li>
                        <li>
                            <i class="fa fa-phone"></i>
                            <a href="" title="">{{ @$site_info->hotline }}</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope"></i>
                            <a href="" title="">{{ @$site_info->email }}</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-2 visible-desktop">
                    <h4>{{ trans('messages.danh_muc') }}</h4>
                    <ul class="ft-nav">
                    @if (App::getLocale() == 'vi')
                        @if (!empty($menuFooter))
                            @foreach ($menuFooter as $item)
                                <li><a href="{{ url($item->url) }}" title="{{ $item->title }}"><i class="fa fa-angle-right"></i> {{ $item->title }}</a> </li>
                            @endforeach
                        @endif
                    @else
                        @if (!empty($menuFooter))
                            @foreach ($menuFooter as $item)
                                <li><a href="{{ url($item->url) }}" title="{{ $item->title_en }}"><i class="fa fa-angle-right"></i> {{ $item->title_en }}</a> </li>
                            @endforeach
                        @endif
                    @endif
                    </ul>
                </div>
                <div class="col-md-2">
                    <h4>{{ trans('messages.chinh_sach') }}</h4>
                    <ul class="ft-nav">
                    @if (App::getLocale() == 'vi')
                        @if (!empty($site_info->chinhsach))
                            @foreach (@$site_info->chinhsach as $item)
                                <li><a href="{{ $item->link }}" title="{{ $item->name }}"><i class="fa fa-angle-right"></i> {{ $item->name }}</a> </li>
                            @endforeach
                        @endif
                    @else
                        @if (!empty($site_info->chinhsach))
                            @foreach (@$site_info->chinhsach as $item)
                                <li><a href="{{ $item->link }}" title="{{ $item->name }}"><i class="fa fa-angle-right"></i> {{ $item->name_EN }}</a> </li>
                            @endforeach
                        @endif
                    @endif
                    </ul>
                </div>
                <div class="col-md-3">
                    <h4> {{ trans('messages.giai_dap') }}</h4>
                    <div class="support suppor-1">
                        <h6>{{ trans('messages.tu_van_mien_phi') }}</h6>
                        <p><a href="#" title="{{ @$site_info->hotline }}">{{ @$site_info->hotline }}</a> </p>
                        <p><a href="#" title="{{ @$site_info->hotline1 }}">{{ @$site_info->hotline1 }}</a> </p>
                    </div>
                    <div class="support suppor-2">
                        <h6>{{ trans('messages.phan_hoi') }}</h6>
                        <p><a href="" title="{{ @$site_info->hotline1 }}">{{ @$site_info->hotline1 }}</a> </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="footer-copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span>{{ @$site_info->copyright }}</span>
                </div>
                <div class="col-md-6">
                    <div class="social flex-center-end">
                        <ul class="flex-center">
                            @if (@$site_info->social)
                                @foreach (@$site_info->social as $item)
                                    <li><a href="{{ $item->link }}" title="{{ $item->name }}" class="{{ $item->icon }}"></a> </li>
                                @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="showrrrr" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	    <div class="modal-dialog modal-dialog-centered bd-example-modal-sm" role="document" style="max-width: 400px ">
	        <div class="modal-content">
	            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="color: black">{{ trans('messages.thong_bao') }}</h5>
	                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                    <span aria-hidden="true">&times;</span>
	                </button>
	            </div>
	            <div class="modal-body" style="color: black">
	                {{ trans('messages.du_lieu_dang_duoc_cap_nhat') }}
	            </div>
	            <div class="modal-footer">
	                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ trans('messages.dong') }}</button>
	            </div>
	        </div>
	    </div>
	</div>
</footer>
