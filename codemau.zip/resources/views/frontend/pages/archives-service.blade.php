@extends('frontend.master')
@section('main')
	<section class="banner-top">
	<div class="banner-photo">
		<img src="{{ @$dataSeo->banner }}" alt="banner">
	</div>
	</section>
	<section class="breadcrumbs">
		<div class="container">
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item">
			    	<a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>
			    </li>
			    <li class="breadcrumb-item active" aria-current="page">{{ trans('messages.dich_vu') }}</li>
			  </ol>
			</nav>
		</div>
	</section>
	<section class="service-us">
		<div class="container">
			<h1 class="d-none">{{ trans('messages.hidden') }}</h1>
			<h3 class="d-none">{{ trans('messages.hidden') }}</h3>
			<div class="service-list">
			@foreach ($services as $key => $service )
				<div class="service-item">
					<div class="row no-margin">
					@if( $key%2 == 0)
						<div class="col-md-6 no-padd">
							<div class="service-content">
								<div class="content-inner">
									<div class="content">
										<h2 class="service-name"><a href="{{route('home.single-service',$service->slug)}}" title="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}">{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}</a></h2>
										<p class="service-des">{!! App::getLocale() == 'vi' ? $service->desc : $service->desc_en !!}</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 no-padd">
							<div class="service-img"><a href="{{route('home.single-service',$service->slug)}}" title="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}">
								<img src="{{ $service->image }}" alt="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}" width="585px" height="350px">
								<span class="border-inner"></span>
							</a></div>
						</div>
					@else
						<div class="col-md-6 no-padd">
							<div class="service-img"><a href="{{route('home.single-service',$service->slug)}}" title="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}">
								<img src="{{ $service->image }}" alt="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}" width="585px" height="350px">
								<span class="border-inner"></span>
							</a></div>
						</div>
						<div class="col-md-6 no-padd">
							<div class="service-content">
								<div class="content-inner">
									<div class="content">
										<h2 class="service-name"><a href="{{route('home.single-service',$service->slug)}}" title="{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}">{{ App::getLocale() == 'vi' ? $service->name : $service->name_en }}</a></h2>
										<p class="service-des">{!! App::getLocale() == 'vi' ? $service->desc : $service->desc_en !!}</p>
									</div>
								</div>
							</div>
						</div>
					@endif
					</div>
				</div>
			@endforeach
			</div>
		</div>
		<section class="paginations">
			{{ $services->links('frontend.components.panigation') }}
		</section>
	</section>

@stop