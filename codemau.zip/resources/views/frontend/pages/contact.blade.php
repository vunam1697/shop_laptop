@extends('frontend.master')
@section('main')
	<?php if(!empty($dataSeo)){
		$content = json_decode($dataSeo->content);
	} ?>
	<section class="contact-us">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="contact-info">
						<div class="store-map">
							<h1 class="contact-title">{{ trans('messages.lien_he_voi_chung_toi') }} </h1>
							<h3 class="d-none">{{ trans('messages.lien_he_voi_chung_toi') }}</h3>
							<div class="map active" id="store-map-1">
				                {!! @$content->address->google_maps1 !!}
				            </div>
                            <div class="map" id="store-map-2">
                                {!! @$content->address2->google_maps2 !!}
                            </div>
						</div>
					</div>
					<div class="system-store">
						<div class="row">
							<div class="col-md-6">
								<div class="store-detail store-main" id="btn-st-1">
									<h2 class="store-name">{{ @$content->address->title }}</h2>
									<ul class="store-info">
										<li>
											<i class="fa fa-map-marker" aria-hidden="true"></i>
											<span> 
												<p class="mgb-10">{{ @$content->address->address }}</p>
											</span>
										</li>
										<li>
											<i class="fa fa-phone" aria-hidden="true"></i>
											<span>{{ @$content->address->phone }}</span>
										</li>
										<li>
											<i class="fa fa-envelope" aria-hidden="true"></i>
											<span>{{ @$content->address->email }}</span>
										</li>
									</ul>
								</div>
							</div>
							<div class="col-md-6">
								<div class="store-detail"  id="btn-st-2">
									<h2 class="store-name">{{ @$content->address2->title2 }}</h2>
									<ul class="store-info">
										<li>
											<i class="fa fa-map-marker" aria-hidden="true"></i>
											<span> {{ @$content->address2->address2 }}</span>
										</li>
										<li>
											<i class="fa fa-phone" aria-hidden="true"></i>
											<span>{{ @$content->address2->phone2 }}</span>
										</li>
										<li>
											<i class="fa fa-envelope" aria-hidden="true"></i>
											<span>{{ @$content->address2->email2 }}</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 flex-end">
					<div class="contact-form">
						<form class="fom-contact" action="{{ route('home.Postcontact') }}" method="POST" id="contact-form" >
						{{ csrf_field() }}
							<fieldset class="fieldset">
								<legend class="title"> {{ trans('messages.gui_phan_hoi') }} </legend>
								@if (Session::has('flash_message'))
									<div class="col-sm-12">
										<div class="item" style="margin-bottom: 15px">
											<div class="alert alert-success alert-dismissible">
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
												<h4><i class="fa fa-check"></i>{{ trans('messages.thong_bao') }} </h4>
												{{ Session::get('flash_message') }}
											</div>
										</div>
									</div>
								@endif
								<div class="field">
                                    <input type="text" name="name" placeholder="{{ trans('messages.ho_va_ten') }}" value="{{ old('name') }}">
                                    @if ($errors->has('name'))
										<span class="help-block">{{ $errors->first('name') }}</span>
									@endif
                                </div>
                                <div class="field">
                                    <input type="emal" name="email" placeholder="{{ trans('messages.email') }}" value="{{ old('email') }}">
                                    @if ($errors->has('email'))
										<span class="help-block">{{ $errors->first('email') }}</span>
									@endif
                                </div>
                                <div class="field">
                                    <input type="number" name="phone" placeholder="{{ trans('messages.dien_thoai') }}" value="{{ old('phone') }}">
                                    @if ($errors->has('phone'))
										<span class="help-block">{{ $errors->first('phone') }}</span>
									@endif
                                </div>
                                <div class="field">
                                	<textarea id="content" placeholder="Nội dung"> {!! old('content') !!}</textarea>
                                	@if ($errors->has('content'))
										<span class="help-block">{{ $errors->first('content') }}</span>
									@endif
                                </div>
							</fieldset>
							<div class="action-toolbar">
                                <button type="submit" class="action submit btn-general">{{ trans('messages.gui') }}</button>
                            </div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
@stop
<style>
	.help-block {
		color: red;
	}
</style>