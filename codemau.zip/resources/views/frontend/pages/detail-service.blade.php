@extends('frontend.master')
@section('main')
<section class="banner-top">
    <div class="banner-photo">
        <img src="{{ @$dataSeo->banner }}" alt="banner">
    </div>
</section>
<section class="service-detail">
    <div class="container">
        <h1 class="sv-title">{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}</h1>
        <div class="sv-content">
            <p class="ablog-shot">{!! App::getLocale() == 'vi' ? $data->desc : $data->desc_en !!}</p>
            <div class="pj-info">
                {!! App::getLocale() == 'vi' ? $data->content : $data->content_en !!}
            </div>
        </div>
    </div>
</section>
@stop
@section('script')
    <script>
        jQuery(document).ready(function($) {
            $('.page-service').addClass('active');
        });
    </script>
@endsection