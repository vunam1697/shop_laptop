@extends('frontend.master')
@section('main')
   <section class="banner-top">
        <div class="banner-photo">
            <img src="{{ @$dataSeo->banner }}" alt="banner">
        </div>
    </section>
    <h3 style="display: none">{{ @$site_info->name_company }}</h3>
    <section class="product-cate pd-60">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    @include('frontend.teamplate.side-bar-product')
                </div>
                <div class="col-md-8">
                    <div class="cate-content">
                        <div class="product-list">
                            <div class="pro-title flex-center-between">
                                <h1>{{ trans('messages.san_pham') }}</h1>
                                <div class="sort flex-center-end">
                                    <span>{{ trans('messages.sap_xep') }}:</span>
                                    <div class="sidebar-dropdown">
                                        <form method="get" action="{{ route('home.Sort') }}" id="form-sort">
                                            <select class="form-control" name="sort" onchange="document.querySelector('#form-sort').submit();" >
                                                <option value="cu-nhat" {{ request()->get('sort') == 'cu-nhat' ? 'selected' : null }} >{{ trans('messages.cu_nhat') }}</option>
                                                <option value="tu-thap-toi-cao" {{ request()->get('sort') == 'tu-thap-toi-cao' ? 'selected' : null }} >{{ trans('messages.tu_thap_toi_cao') }}</option>
                                                <option value="tu-cao-toi-thap" {{ request()->get('sort') == 'tu-cao-toi-thap' ? 'selected' : null }} >{{ trans('messages.tu_cao_xuong_thap') }}</option>
                                            </select>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="list-content">
                                <div class="row list-append">
                                    @if (count($products) > 0)
                                        @foreach ($products as $item)
                                            <div class="col-md-4">
                                                @component('frontend.components.product', ['item' => $item]) @endcomponent
                                            </div>
                                        @endforeach
                                    @else
                                        <div class="col-lg-12">
                                            <div class="col-sm-12">
                                                <div class="alert alert-success" role="alert">
                                                    {{ trans('messages.khong_co_san_pham_nao_phu_hop') }}
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                <div class="col-md-12">
                                    <div class="text-center"><a href="javascript:;" title="xem tất cả" class="view-mores inflex-center-center">Xem tất cả</a> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@stop
@section('script')
<script type="text/javascript">
    $('#sort a').on('click', function(){
        var url = $(this).attr('href');
        var name = $(this).attr('data-name');
        $.ajax({
            url: url,
            type:'GET',
            data: {
                slug: name,
            },
            success: function (response) {

            },
        })
        window.location($(this).attr('href'));
    });

    jQuery(document).ready(function($) {
			limit = 12;
			$('.view-mores').click(function(event) {
				btn = $(this);
				$('.loadingcover').show();
				$.ajax({
					url: '{{ route('home.load-more-ajax') }}',
					type: 'GET',
					data: {
						type : 'products',
						limit : limit,
					},
				})
				.done(function(data) {
					$('.loadingcover').hide();
					limit = limit + 12;
					$('.list-append').append(data);
					if (data.status == 0){
						$('#showrrrr').modal('show');
						btn.remove();
					}
				})
			});
		});
</script>
@endsection