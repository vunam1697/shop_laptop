@extends('frontend.master')
@section('main')

<section class="breadcrumbs">
	<div class="container">
		<nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item">
		    	<a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>
		    </li>
		    <li class="breadcrumb-item active" aria-current="page">{{ trans('messages.tin_tuc') }}</li>
		  </ol>
		</nav>
	</div>
</section>
<section class="news-list">
	<div class="container">
		<h1 class="d-none">{{ trans('messages.tin_tuc') }}</h1>
		<h3 class="d-none">{{ trans('messages.tin_tuc') }}</h3>
		<div class="row">
			<div class="col-md-9">
				<ul class="amblog-nav">
					@if (count($listCategory))
						@foreach ($listCategory as $item)
							<li class="amblog-nav-item {{ $loop->index == 0 ? 'active' : null }}">
								<a href="{{ route('home.category-news', ['slug' => $item->slug]) }}" 
									title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">
									{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }} </a>
							</li>
						@endforeach
					@endif
				</ul>
				<div class="amblog-content">
					<div class="row list-append">
						@if (count($listCategory))
							@foreach ($listCategory as $key => $cate)
								@if ($key == 0)
									@foreach ($data as $item)
										@if ($item->id_category == $cate->id)
											<div class="col-md-4">
												@component('frontend.components.post', ['item' => $item]) @endcomponent
											</div>
										@endif
									@endforeach
								@endif
							@endforeach
						@endif
					</div>
					<div class="view-more">
						<a href="javascript:;" class="view-link">Xem thêm</a>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="news-hot sticky-top">
					<h2 class="news-title"> {{ trans('messages.xem_nhieu_nhat') }}</h2>
					<div class="blog-trend">
						@foreach ($dataHot as $item)
							<div class="blog-trend__item">
								<div class="row">
									<div class="col-md-6">
										<div class="blogtrend-photo">
											<a href="{{ route('home.post.single', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}"><img src="{{ @$item->image}}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="120px" height="80px"></a>
										</div>
									</div>
									<div class="col-md-6">
										<h6 class="blogtrend-name"><a href="{{ route('home.post.single', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a></h6>
									</div>
								</div>
							</div>
						@endforeach
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

@stop
@section('script')
	<script>
		jQuery(document).ready(function($) {
			limit = 12;
			$('.view-link').click(function(event) {
				btn = $(this);
				$('.loadingcover').show();
				$.ajax({
					url: '{{ route('home.load-more-ajax') }}',
					type: 'GET',
					data: {
						type : 'news',
						limit : limit,
						@if (!empty($listCategory))
							id_cat : '{{ $listCategory[0]->id }}',
						@endif
					},
				})
				.done(function(data) {
					$('.loadingcover').hide();
					limit = limit + 12;
					$('.list-append').append(data);
					if (data.status == 0){
						$('#showrrrr').modal('show');
						btn.remove();
					}
				})
			});
		});
	</script>
@endsection

