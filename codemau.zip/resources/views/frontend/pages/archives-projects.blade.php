@extends('frontend.master')
@section('main')
<section class="banner-top">
		<div class="banner-photo">
			<img src="{{ $dataSeo->banner }}" alt="banner">
		</div>
	</section>
	<section class="breadcrumbs">
		<div class="container">
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item">
			    	<a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>
			    </li>
			    <li class="breadcrumb-item active" aria-current="page">{{ trans('messages.du_an') }}</li>
			  </ol>
			</nav>
		</div>
	</section>
	<section class="project-list">
		<div class="container">
			<h1 class="d-none">{{ trans('messages.hidden') }}</h1>
			<h2 class="d-none">{{ trans('messages.hidden') }}</h2>
			<h3 class="d-none">{{ trans('messages.hidden') }}</h3>
			<div class="row">
			@foreach ($projects as $key)
				<div class="col-md-4">
					<div class="pj-item">
						<div class="pj-photo">
							<a href="{{ route('home.single-project',$key->slug)}}" class="pj-item-photo" title="{{ App::getLocale() == 'vi' ? $key->name : $key->name_en }}">
								<img src="{{ $key->image }}" alt="{{ App::getLocale() == 'vi' ? $key->name : $key->name_en }}" width="370px" height="195px">
								<span class="pj-view"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
							</a>
						</div>
						<div class="pj-detail">
							<h4 class="pj-name"><a href="{{ route('home.single-project',$key->slug)}}" title="{{ App::getLocale() == 'vi' ? $key->name : $key->name_en }}">{{ App::getLocale() == 'vi' ? $key->name : $key->name_en }}</a></h4> 
							<p class="pj-des">{!! App::getLocale() == 'vi' ? $key->desc : $key->desc_en !!}</p>
						</div>
					</div>
				</div>
			@endforeach
			</div>
		</div>
		
		<section class="paginations">
			{{ $projects->links('frontend.components.panigation') }}
		</section>
	</section>

	@stop