@extends('frontend.master')
@section('main')
    <section class="banner-top">
		<div class="banner-photo">
			<img src="{{url('/')}}/images/service-bn.png" alt="">
		</div>
	</section>
	<section class="product-detail">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
                   @include('frontend.teamplate.side-bar-product')
                </div>
				<div class="col-md-9">
					<div class="row">
                        <div class="col-md-6 col-sm-6">
                            @if ($data->more_image)
                                <?php if(!empty($data->more_image)){
                                    $more_image = json_decode($data->more_image);
                                } ?>
                                <div class="slide-thumbs">
                                    <div class="slider-for">
                                        @if (!empty($more_image))
                                            @foreach ($more_image as $key => $item)
                                                <div class="carousel-item">
                                                    <img src="{{ $item }}" alt="{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}" width="450px" height="450px">
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                    <div class="slider-nav">
                                        @if (!empty($more_image))
                                            @foreach ($more_image as $key => $item)
                                                <div class="clc">
                                                    <div class="item"><img src="{{ $item }}" width="100px" height="110px" alt="{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}"></div>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                </div>
                            @else
                                <img src="{{ $data->image }}" alt="{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}" width="450px" height="450px">
                            @endif
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="product-info-main">
                                <h1 class="title-wrapper">{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}</h1>
                                <div class="atrr-overview">
                                    <p class="sku">Mã SP: {{ $data->code }}</p>
                                    <div class="price-wrapper">{{ trans('messages.gia') }}: <span class="price">{{ $data->price != 0 ? number_format($data->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</span></div>
                                    @if (App::getLocale() == 'vi')
                                        @if( $data->size == 'to')
                                            <p>{{ trans('messages.kich_thuoc_to') }} </p>
                                        @endif
                                        @if( $data->size == 'trung-binh')
                                            <p>{{ trans('messages.kich_thuoc_tb') }}</p>
                                        @endif
                                        @if( $data->size == 'nho')
                                            <p>{{ trans('messages.kich_thuoc_nho') }}</p>
                                        @endif
                                        <p>{{ trans('messages.bao_hanh') }}: {{ $data->guarantee }}</p>
                                    @else
                                        @if( $data->size_en == 'big')
                                            <p>{{ trans('messages.kich_thuoc_to') }} </p>
                                        @endif
                                        @if( $data->size_en == 'medium')
                                            <p>{{ trans('messages.kich_thuoc_tb') }}</p>
                                        @endif
                                        @if( $data->size_en == 'small')
                                            <p>{{ trans('messages.kich_thuoc_nho') }}</p>
                                        @endif
                                        <p>{{ trans('messages.bao_hanh') }}: {{ $data->guarantee_en }}</p>
                                    @endif
                                </div>
                                <div class="product-option">
                                    <button class="action tocart btn-general">{{ trans('messages.dat_hang') }}</button>
                                    <a href="#" class="contact-phone action btn-general">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                        <span>{{ trans('messages.tu_van') }}: {{ @$site_info->hotline }}</span>
                                    </a>
                                </div>
                            </div>
                        </div>
				    </div>
                    <div class="product-tab">
                        <ul class="nav nav-tabs nav-tabs-start" id="navTab" role="tabblist">
                            <li class="nav-item">
                                <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">{{ trans('messages.mo_ta') }}</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="specification-tab" data-toggle="tab" href="#specification" role="tab" aria-controls="specification" aria-selected="false">{{ trans('messages.thong_so_ky_thuat') }}</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="navTabContent">
                            <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                                <div class="tab-detail">
                                    {!! App::getLocale() == 'vi' ? $data->desc : $data->desc_en !!}
                                </div>
                            </div>
                            <div class="tab-pane fade" id="specification" role="tabpanel" aria-labelledby="specification-tab">
                                <div class="tab-detail">
                                    {!! App::getLocale() == 'vi' ? $data->specifications : $data->specifications_en !!}
                                </div>
                            </div>
                        </div>
				    </div>  
			    </div>
		    </div>
	    </div>
    </section>
<section class="pro-related">
    <div class="container">
        <h2 class="title font-30">{{ trans('messages.sp_lien_quan') }}</h2>
        <div class="pro-related-box">
        @if(count($product_same_category) > 0 )
            <div class="row">
                @foreach ($product_same_category as $item)
                    <div class="col-md-3">
                        <div class="product-item">
                            <a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="" class="zoom"><img src="{{ $item->image }}" alt="" width="270px" height="300px"> </a>
                            <div class="product-text">
                                <h4><a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" class="text-left">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a> </h4>
                                <div class="price text-left">
                                {{ trans('messages.gia') }}: 
                                    <span>{{ $item->price != 0 ? number_format($item->price, 0, '.', '.').' đ' : 'Liên hệ' }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            @else
            <div class="col-lg-12">
                <div class="col-sm-12">
                    <div class="alert alert-success" role="alert">
                        {{ trans('messages.khong_co_sp_lien_quan') }}
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</section>
<section class="pro-watched pd-60">
    <div class="container">
        <h2 class="title font-30">{{ trans('messages.sp_da_xem') }}</h2>
        <div class="pro-watched-slider">
        @foreach ($products as $item)
            <div class="col-md-12">
                <div class="product-item">
                    <a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="" class="zoom"><img src="{{ $item->image }}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="270px" height="300px"    > </a>
                    <div class="product-text">
                        <h4><a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" class="text-left">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a> </h4>
                        <div class="price text-left">
                            {{ trans('messages.gia') }}: 
                                <span>{{ $item->price != 0 ? number_format($item->price, 0, '.', '.').' đ' : 'Liên hệ' }}</span>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
        </div>
    </div>
</section>
@stop
@section('script')
    <script>
        jQuery(document).ready(function($) {
            $('.page-product').addClass('active');
        });
    </script>
@endsection