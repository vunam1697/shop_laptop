@extends('frontend.master')
@section('main')
<section class="banner-top">
    <div class="banner-photo">
        <img src="{{url('/')}}/images/service-bn.png" alt="banner">
    </div>
</section>
<h3 class="d-none">{{ trans('messages.hidden') }}</h3>
<section class="product-cate pd-60">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                @include('frontend.teamplate.side-bar-product')
            </div>
            <div class="col-md-8">
                <div class="cate-content">
                    @if (App::getLocale() == 'vi')
                        <h1 class="text-center title-40">{{ $category->name }}</h1>
                    @else
                        <h1 class="text-center title-40">{{ $category->name_en }}</h1>
                    @endif
                    <div class="cate-child">
                        @if (isset($childCates) && $childCates->count())
                            @foreach ($childCates as $childCate)
                                <div class="child-title flex-center-between">
                                    @if (App::getLocale() == 'vi')
                                        <h2><a href="{{ route('home.category-product', ['slug' => $childCate->slug]) }}" title="">{{ $childCate->name }}</a> </h2>
                                    @else
                                        <h2><a href="{{ route('home.category-product', ['slug' => $childCate->slug]) }}" title="">{{ $childCate->name_en }}</a> </h2>
                                    @endif
                                    <a href="{{ route('home.category-product', ['slug' => $childCate->slug]) }}" title="{{ App::getLocale() == 'vi' ? $childCate->name : $childCate->name_en }}" class="view-mores inflex-center-center">{{ trans('messages.xem_them') }}</a>
                                </div>
                                <div class="child-content">
                                    <div class="row">
                                        @if (!empty($childCate->Products))
                                            @foreach ($childCate->Products()->get() as $product)
                                                <div class="col-md-4">
                                                    <div class="product-item">
                                                        <a href="{{ route('home.SingleProduct', ['slug' => $product->slug]) }}" title="{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}" class="zoom"><img src="{{ $product->image }}" alt="{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}" width="270px" height="300px"> </a>
                                                        <div class="product-text text-center">
                                                            <h4><a href="product-detail.php" title="">{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}</a> </h4>
                                                            <div class="price">{{ $product->price != 0 ? number_format($product->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                </div>
                                <br>
                                <br>
                            @endforeach
                        @else
                            @if (count($category->Products))
                                <div class="child-content">
                                    @if (!empty($category->Products))
                                        <div class="row">
                                            @foreach ($category->Products()->paginate(9) as $product)
                                                <div class="col-md-4">
                                                    <div class="product-item">
                                                        <a href="{{ route('home.SingleProduct', ['slug' => $product->slug]) }}" title="{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}" class="zoom"><img src="{{ $product->image }}" alt="{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}" width="270px" height="300px"> </a>
                                                        <div class="product-text text-center">
                                                            <h4><a href="product-detail.php" title="">{{ App::getLocale() == 'vi' ? $product->name : $product->name_en }}</a> </h4>
                                                            <div class="price">{{ $product->price != 0 ? number_format($product->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <br>
                                        <br>
                                        <div class="row">
                                            <ul class="paginations" style="margin: auto">
                                                {{ $category->Products()->paginate(9)->links('frontend.components.panigation') }}
                                            </ul>
                                        </div>
                                    @endif
                                </div>
                            @else
                                <div class="col-lg-12">
                                    <div class="col-sm-12">
                                        <div class="alert alert-success" role="alert">
                                            {{ trans('messages.khong_co_san_pham_nao_phu_hop') }}
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@stop
@section('script')
    <script>
        jQuery(document).ready(function($) {
            $('.page-product').addClass('active');
        });
    </script>
@endsection