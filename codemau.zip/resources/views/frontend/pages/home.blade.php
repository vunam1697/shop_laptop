@extends('frontend.master')
@section('main')
<section class="banner-slider">
    @foreach ($slider as $item)
        <div class="item"><a href="{{ $item->link }}" title="{{ $item->name }}"><img src="{{ $item->image }}" alt="{{ $item->name }}" title="{{ $item->name }}"> </a></div>
	@endforeach
</section>
<h1 style="display: none">{{ @$site_info->name_company }}</h1>
<?php if(!empty($contentHome)){
    $content = json_decode($contentHome->content);
} ?>
<section class="about-index pd-60 block-gray">
    <div class="container">
        <h2 class="title"> {{ @$content->about->title_box }} </h2>
        <div class="row">
            <div class="col-md-6">
                <a href="{{ @$content->about->link }}" title="{{ @$content->about->title }}" class="zoom"><img src="{{ @$content->about->image_about }}" alt="{{ @$content->about->title }}"> </a>
            </div>
            <div class="col-md-6">
                <div class="about-text">
                    <h3>{{ @$content->about->title }}</h3>
                    <p>{!! @$content->about->content !!}</p>
                    <a href="{{ route('home.about') }}" title="{{ @$content->about->title }}" class="link-plus">{{ trans('messages.xem_them') }}</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="block-group pd-60">
    <div class="container">
        <h2 class="title">{{ trans('messages.sp_noi_bat') }}</h2>
        <div class="product-slider">
        @foreach ($productsHot as $item)
            <div class="col-md-12">
                <div class="product-item">
                    <a href="{{route('home.SingleProduct',$item->slug)}}" title="{{ $item->name }}" class="zoom"><img src="{{ $item->image }}" alt="{{ $item->name }}" width="270px" height="300px"> </a>
                    <div class="product-text">
                        <h4><a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="{{ $item->name }}">{{ $item->name }}</a> </h4>
                        <div class="price">
							<span>{{ $item->price != 0 ? number_format($item->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</span>
						</div>
                    </div>
                </div>
            </div>
		@endforeach
        </div>
        <div class="text-center mgt-50"><a href="{{ route('home.product') }}" title="{{ trans('messages.xem_tat_ca') }}" class="view-mores inflex-center-center">{{ trans('messages.xem_tat_ca') }}</a> </div>
    </div>
</section>
<section class="service-index">
    <div class="container">
        <h2 class="title title-white">{{ trans('messages.dich_vu') }}</h2>
        <div class="service-slider">
        @foreach ($services as $item)
            <div class="col-md-12">
                <div class="ser-item">
                    <a href="{{route('home.single-service',$item->slug)}}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" class="ser-image zoom"><img src="{{ $item->image }}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}"> </a>
                    <h4><a href="{{route('home.single-service',$item->slug)}}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a></h4>
                </div>
            </div>
        @endforeach
        </div>
    </div>
</section>

<section class="why-choose pd-60">
    <div class="container">
        <h2 class="title">{{ @$content->contentReason->title_box }}</h2>
        <div class="row">
            @foreach (@$content->contentReason->list as $item)
                <div class="col-md-3">
                    <div class="why-item">
                        <div class="why-image">
                            <span class="inflex-center-center"><img src="{{ $item->icon}}" title="icon"> </span>
                        </div>
                        <h4> {{ $item->title }} </h4>
                        <p> {{ $item->desc }} </p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>

<section class="project-index">
    <div class="container">
        <h2 class="title">{{ trans('messages.du_an_chung_toi') }}</h2>
        <div class="row">
            @foreach ($projects as $item)
                <div class="col-md-6">
                    <div class="pjs-item">
                    <a href="{{route('home.single-project',$item->slug)}}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" class="zoom"><img src="{{ @$item->image}}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="570px" height="300px"> </a>
                        <div class="pj-name">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
<section class="news-index pd-60">
    <div class="container">
        <h2 class="title">{{ trans('messages.tin_ruc_noi_bat') }}</h2>
        <div class="row">
            @foreach ($postHots as $item)
                <div class="col-md-3">
                    <div class="amblog-item">
                        <div class="amblog-photo"><a href="{{ route('home.post.single', ['slug' => $item->slug]) }}" class="zoom">
                                <img src="{{ $item->image}}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="270px" height="180px">
                            </a></div>
                        <div class="amblog-detail">
                            <p class="news-date">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <span>{{ $item->created_at->format('d/m/Y')}}</span>
                            </p>
                            <h4 class="news-name"><a href="{{ route('home.post.single', ['slug' => $item->slug]) }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a></h4>
                            <p class="news-des">{{ App::getLocale() == 'vi' ? $item->desc : $item->desc_en }}</p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
<section class="partner pd-60">
    <div class="container">
        <h2 class="title"> {{ trans('messages.doi_tac_cua_chung_toi') }} </h2>
        <div class="partner-slider">
         @foreach ($partner as $item)
            <div class="part-item"><a href="{{ $item->link }}" title="{{ $item->name }}" class="zoom-2"><img src="{{ @$item->image}}" alt="{{ $item->name }}" title="{{ $item->name }}"> </a></div>
        @endforeach
        </div>
    </div>
</section>
@endsection