@extends('frontend.master')
@section('main')
		<div class="banner-photo">
			<img src="{{ @$dataSeo->banner }}" alt="banner">
		</div>
	</section>
	<section class="breadcrumbs">
		<div class="container">
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item">
			    	<a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>
			    </li>
			    <li class="breadcrumb-item">
			    	<a href="#">{{ trans('messages.du_an') }}</a>
			    </li>
			    <li class="breadcrumb-item active" aria-current="page">{{ trans('messages.chi_tiet_du_an') }}</li>
			  </ol>
			</nav>
		</div>
	</section>
	<section class="project-list">
		<div class="container">
			<h1 class="d-none">{{ trans('messages.hidden') }}</h1>
			<div class="row">
				<div class="col-md-9 padd-large">
					<h2 class="pjdetail-title">{{ App::getLocale() == 'vi' ? $data->name : $data->name_en }}</h2>
					{{-- <div class="investor-info">
						<p><strong>- {{ trans('messages.chu_dau_tu') }}:</strong></p>
						<p><strong>- {{ trans('messages.dia_chi') }}: </strong></p>
						<p><strong>- {{ trans('messages.dien_tich') }}:</strong></p>
						<p><strong>- {{ trans('messages.thơi_gia_thi_cong') }}:</strong></p>
					</div> --}}
					<div class="pj-info">
						{!! App::getLocale() == 'vi' ? $data->content : $data->content_en !!}
					</div>
				</div>
				<div class="col-md-3">
					<div class="news-hot sticky-top">
						<h2 class="news-title">{{ trans('messages.du_an_lien_quan') }}</h2>
						<div class="blog-trend">
							@foreach ($project_same as $item)
							<div class="blog-trend__item">
								<div class="row">
									<div class="col-md-6">
										<div class="blogtrend-photo">
											<a href="{{ route('home.single-project', ['slug' => $item->slug]) }}"><img src="{{ $item->image }}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="120px" height="80px"></a>
										</div>
									</div>
									<div class="col-md-6">
										<h6 class="blogtrend-name"><a href="{{ route('home.single-project', ['slug' => $item->slug]) }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a></h6>
									</div>
								</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</section>
@stop
@section('script')
    <script>
        jQuery(document).ready(function($) {
            $('.page-project').addClass('active');
        });
    </script>
@endsection