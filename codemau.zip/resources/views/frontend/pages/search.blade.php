@extends('frontend.master')
@section('main')
   <section class="banner-top">
        <div class="banner-photo">
            <img src="{{ @$dataSeo->banner }}" alt="banner">
        </div>
    </section>
    <h3 class="d-none">{{ trans('messages.hidden') }}</h3>
    <section class="product-cate pd-60">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    @include('frontend.teamplate.side-bar-product')
                </div>
                <div class="col-md-8">
                    <div class="cate-content">
                        <div class="product-list">
                            <div class="pro-title flex-center-between">
                                {{-- {{ trans('messages.san_pham') }} --}}
                                <h1>Kết quả tìm kiếm</h1>
                                <div class="sort flex-center-end">
                                    <span>{{ trans('messages.sap_xep') }}:</span>
                                    <div class="sidebar-dropdown">
                                        {{-- <form method="get" action="{{ route('home.Sort') }}" id="form-sort">
                                            <select class="form-control" name="sort" onchange="document.querySelector('#form-sort').submit();" >
                                                <option value="cu-nhat" {{ request()->get('sort') == 'cu-nhat' ? 'selected' : null }} >{{ trans('messages.cu_nhat') }}</option>
                                                <option value="tu-thap-toi-cao" {{ request()->get('sort') == 'tu-thap-toi-cao' ? 'selected' : null }} >{{ trans('messages.tu_thap_toi_cao') }}</option>
                                                <option value="tu-cao-toi-thap" {{ request()->get('sort') == 'tu-cao-toi-thap' ? 'selected' : null }} >{{ trans('messages.tu_cao_xuong_thap') }}</option>
                                            </select>
                                        </form> --}}
                                        <div class="current-select">{{ trans('messages.moi_nhat') }}</div>
                                        <div class="dropdown-select" id="sort">
                                            <ul>
                                            <li><a href="{{ route('home.Sort', ['slug' => 'cu-nhat', 'type' => 'search']) }}" title="{{ trans('messages.cu_nhat') }}">{{ trans('messages.cu_nhat') }}</a></li>
                                                <li><a href="{{ route('home.Sort', ['slug' => 'tu-thap-toi-cao', 'type' => 'search']) }}" title="{{ trans('messages.tu_thap_toi_cao') }}" >{{ trans('messages.tu_thap_toi_cao') }}</a></li>
                                                <li><a href="{{ route('home.Sort', ['slug' => 'tu-cao-toi-thap', 'type' => 'search']) }}" title="{{ trans('messages.tu_cao_xuong_thap') }}">{{ trans('messages.tu_cao_xuong_thap') }}</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="list-content">
                                <div class="row">
                                @if (count($products) > 0)
                                    @foreach ($products as $item)
                                        <div class="col-md-4">
                                            <div class="product-item">
                                                <a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="" class="zoom"><img src="{{ $item->image }}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}"> </a>
                                                <div class="product-text text-left">
                                                    <h4><a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="">{{ $item->name }}</a> </h4>
                                                    <div class="price"> {{ trans('messages.gia') }}:
                                                        <span>{{ $item->price != 0 ? number_format($item->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @else
                                    <div class="col-lg-12">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success" role="alert">
                                                {{ trans('messages.khong_co_san_pham_nao_phu_hop') }}
                                            </div>
                                        </div>
                                    </div>
                                @endif
                                   
                                <div class="col-sm-12">
                                    <div class="paginations">
                                        {{ $products->links('frontend.components.panigation') }}
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@stop
@section('script')
    <script type="text/javascript">
        $('#sort a').on('click', function(){
            var url = $(this).attr('href');
            window.location($(this).attr('href'));
            $.ajax({
                url: url,
                type:'GET',
                success: function (response) {
                },
            })
        });
        
    </script>
@endsection