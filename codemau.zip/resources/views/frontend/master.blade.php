<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="{{ $site_info->favicon }}">
	@if (isset($site_info->index_google))
		<meta name="robots" content="{{ $site_info->index_google == 1 ? 'index, follow' : 'noindex, nofollow' }}">
	@else
		<meta name="robots" content="noindex, nofollow">
	@endif
	{!! SEO::generate() !!}
	<meta name='revisit-after' content='1 days' />
	<meta name="copyright" content="GCO" />
	<meta http-equiv="content-language" content="vi" />
	<meta name="geo.region" content="VN" />
    <meta name="geo.position" content="10.764338, 106.69208" />
    <meta name="geo.placename" content="Hà Nội" />
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
 	<meta name="_token" content="{{csrf_token()}}" />
 	<link rel="canonical" href="{{ \Request::fullUrl() }}">


	 <!--link css-->
	 
    <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/bootstrap.min.css">

    {{-- <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/font-awesome.min.css"> --}}

    <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/slick.min.css">

    <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/slick-theme.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css" />

	<link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/jquery.mmenu.all.css"> 
	
	{{-- <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/fonts.css"> --}}

	<link rel="stylesheet" type="text/css" href="{{ __BASE_URL__ }}/css/reset.css">

    <link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/styles.css">

	<link rel="stylesheet" type="text/css" title="" href="{{ __BASE_URL__ }}/css/responsive.css">
	
	<meta name="viewport" content="width=device-width, initial-scale=1"> 

    <script type="text/javascript" src="{{ __BASE_URL__ }}/js/jquery.min.js"></script> 
 	

 	@if (!empty($site_info->google_analytics))
 		{!! $site_info->google_analytics !!}
 	@endif

</head> 
	<body>

		<div class="loadingcover" style="display: none;">
		    <p class="csslder">
		        <span class="csswrap">
		            <span class="cssdot"></span>
		            <span class="cssdot"></span>
		            <span class="cssdot"></span>
		        </span>
		    </p>
		</div>

		@include('frontend.teamplate.header')
			<main>
				@yield('main')
			</main>

		@include('frontend.teamplate.footer')

		<a href="#" id="back-to-top" class=""><i class="fa fa-chevron-up"></i> </a>
		<div id="callnow" class="">
			<div class="hotline-phone-ring-wrap">
				<div class="hotline-phone-ring" id="call-now-1">
					<div class="hotline-phone-ring-circle"></div>
					<div class="hotline-phone-ring-circle-fill"></div>
					<div class="hotline-phone-ring-img-circle">
						<a href="tel:{{ @$site_info->hotline1 }}" class="pps-btn-img"> <img src="{{ url('/') }}/images/quick.png" alt="Gọi điện thoại" width="50" data-lazy-src="" data-pin-no-hover="true" class="lazyloaded" data-was-processed="true">
						</a>
					</div>
				</div>
				<div class="hotline-bar">
					<a href="tel:{{ @$site_info->hotline1 }}"> <span class="text-hotline" id="call-now-1">{{ @$site_info->hotline1 }}</span> </a>
				</div>
			</div>
		</div>
		

		<!--Link js-->

		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/jquery.min.js"></script> 
		
		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/bootstrap.min.js"></script>

		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/jquery.mmenu.all.js"></script>

		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/slick.min.js"></script>

		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/private.js"></script>

		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>

		<script type="text/javascript" src="{{ __BASE_URL__ }}/plugin/jquery.toast.min.js"></script>
		
		{{-- <script type="text/javascript" src="{{ __BASE_URL__ }}/js/jquery.counterup.min.js"></script>

		<script type="text/javascript" src="{{ __BASE_URL__ }}/js/waypoints.min.js"></script> --}}

		@yield('script')
		@if (!empty($site_info->script))
			{!! $site_info->script !!}
		@endif

		@if (Session::has('toastr'))
			<script>
				jQuery(document).ready(function($) {
					showToast('{{ Session::get('toastr') }}', 'Thông báo');
				});
			</script>
		@endif
	
		<script>
			function setLang(lang='en') {
				event.preventDefault();
				document.querySelector('input[name=current_lang]').value = lang; 
				document.getElementById('appLangControl').submit();
			}
		</script>
	</body>
</html>