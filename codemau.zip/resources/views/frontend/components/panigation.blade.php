@if ($paginator->hasPages())
    <!-- Pagination -->
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            {{-- Previous Page Link --}}
            @if ($paginator->onFirstPage())
                
            @else
                <li>
                    <a class="page-link" href="{{ $paginator->previousPageUrl() }}" tabindex="-1"><i class="fa fa-angle-double-left" aria-hidden="true"></i></a>
                  </li>
            @endif

            {{-- Pagination Elements --}}
            @foreach ($elements as $element)
                {{-- Array Of Links --}}
                @if (is_array($element))
                    @foreach ($element as $page => $url)
                        @if ($page == $paginator->currentPage())
                            <li><a class="page-link active" href="{{ $url }}">{{ $page }}</a></li>
                        @elseif (($page == $paginator->currentPage() + 1 || $page == $paginator->currentPage() + 2) || $page == $paginator->lastPage())
                            <li><a class="page-link" href="{{ $url }}">{{ $page }}</a></li>
                        @elseif ($page == $paginator->lastPage() - 1 || $page == $paginator->lastPage() - 2 || $paginator->currentPage())
                            <li class="active"><a class="page-link" href="{{ $url }}">{{ $page }}</a></li>
                        @endif
                    @endforeach
                @endif
            @endforeach

            {{-- Next Page Link --}}
            @if ($paginator->hasMorePages())
                <li>
                    <a class="page-link" href="{{ $paginator->nextPageUrl() }}"><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>
            @endif
        </ul>
    </nav>
    <!-- Pagination -->
@endif
<style>
    .paginations ul > li {
        margin-right: 8px;
    }
    .paginations a.active{
        z-index: 1;
        color: #fff;
        background: #007bff;
        border-color: #007bff;
    }
</style>
