<div class="product-item">
    <a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" class="zoom"><img src="{{ $item->image }}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="270px" height="300px"> </a>
    <div class="product-text text-left">
        <h4><a href="{{ route('home.SingleProduct', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a> </h4>
        <div class="price">{{ trans('messages.gia') }}:
            <span>{{ $item->price != 0 ? number_format($item->price, 0, '.', '.').' đ' : trans('messages.lien_he') }}</span>
        </div>
    </div>
</div>