@if ($type == 'news')
	@if (count($data))
		@foreach ($data as $item)
			<div class="col-md-4">
				@component('frontend.components.post', ['item' => $item]) @endcomponent
			</div>
		@endforeach
	@endif
@else
	@if (count($data))
		@foreach ($data as $item)
			<div class="col-md-4">
				@component('frontend.components.product', ['item' => $item]) @endcomponent
			</div>
		@endforeach
	@endif
@endif