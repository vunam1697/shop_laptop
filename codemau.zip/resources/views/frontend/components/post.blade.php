<div class="amblog-item">
	<div class="amblog-photo"><a href="{{ route('home.post.single', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">
		<img src="{{ @$item->image}}" alt="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}" width="270px" height="180px">
	</a></div>
	<div class="amblog-detail">
		<p class="news-date">
			<i class="fa fa-calendar" aria-hidden="true"></i>
			<span>{{ $item->created_at->format('d/m/Y') }}</span>
		</p>
		<h4 class="news-name"><a href="{{ route('home.post.single', ['slug' => $item->slug]) }}" title="{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}">{{ App::getLocale() == 'vi' ? $item->name : $item->name_en }}</a></h4>
		<p class="news-des">{{ App::getLocale() == 'vi' ? $item->desc : $item->desc_en }}</p>
	</div>
</div>